<?php
require __DIR__ . '/../../../../vendor/autoload.php';
use src\ModSPL\StandardDatastructures\SplPriorityQueue\{Event, EventManager};

// Build some callbacks
$preCheck = function (Event $e){
    echo $e->getName();
};

$statusCheck = function (Event $e){
    echo $e->getName();
};

$checkComplete = function (Event $e){
    echo 'Ignition -- Let\'s go!';
};

$eventManager = new EventManager();

// Attach prioritized listeners--priority assigned as needed. Change priorities and watch the calls change.
$eventManager->attach('onCheck.pre', $preCheck, 1);
$eventManager->attach('onCheck.process', $statusCheck, 3);
$eventManager->attach('onCheck.post', $checkComplete, 2);

// Just before check start, trigger pre stage
$eventManager->trigger('onCheck.pre');

// Just before check start, trigger status check
$eventManager->trigger('onCheck.process');

// Checklist complete
$eventManager->trigger('onCheck.post');

