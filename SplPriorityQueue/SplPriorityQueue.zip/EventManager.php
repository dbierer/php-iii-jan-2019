<?php
// Event Manager Class
namespace src\ModSPL\StandardDatastructures\SplPriorityQueue;

class EventManager {
    protected $events = [];
    protected $queueClass;

    public function __construct(){
        // Inject the queue
        $this->queueClass = new Queue;
    }

    public function attach($event, $listener, $priority){
        // Generate an event wrapper for each event
        $this->events[$event] = new Event($event);

        // Add the listener to the queue
        $this->queueClass->insert($listener, $priority);
        return true;
    }

    public function trigger($event){
        $this->notify($this->events[$event]);
        return true;
    }

    protected function notify($eventObject){
        // Iterate the queue by priority and call listeners
        foreach ($this->queueClass as $listener) {
            call_user_func($listener, $eventObject);
        }
    }
}
